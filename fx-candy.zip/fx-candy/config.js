const fxCandyConfig = [
    {
        folder : "images/Background",
        values : [
            {
                file : "Base"
            }
        ]
    },
    {
        folder : "images/Eyes",
        values : [
            {
                file : "Bottom_Right"
            },
            {
                file : "Cartoon_Eyes"
            },
            {
                file : "Center"
            },
            {
                file : "Crossed"
            },
            {
                file : "Normal_Eyes"
            },
            {
                file : "Top_Right"
            },
        ]
    },
    {
        folder : "images/Glasses",
        values : [
            {
                file : "Green"
            },
            {
                file : "Pink"
            },
            {
                file : "Yellow"
            },
        ]
    },
    {
        folder : "images/Mouth",
        values : [
            {
                file : "Bleh"
            },
            {
                file : "Fine"
            },
            {
                file : "Lips"
            },
            {
                file : "Open"
            },
            {
                file : "Smile"
            },
            {
                file : "Tongue"
            },
        ]
    },
]
